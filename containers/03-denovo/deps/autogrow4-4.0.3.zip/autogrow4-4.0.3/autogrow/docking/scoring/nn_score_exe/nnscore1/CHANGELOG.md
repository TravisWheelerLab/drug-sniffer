Changes
=======

NNScore 1.1
-----------

* Now works with Python3.
* Added `README.md`, `CHANGELOG.md`, and `CONTRIBUTORS.md` files.
* Added `examples/` directory.
