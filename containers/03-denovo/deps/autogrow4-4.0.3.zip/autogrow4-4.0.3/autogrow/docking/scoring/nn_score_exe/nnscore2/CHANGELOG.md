Changes
=======

NNScore 2.02
------------

* Now works with Python3.
* Added `README.md`, `CHANGELOG.md`, and `CONTRIBUTORS.md` files.
* Added `examples/` directory.

