python ../run_gypsum_dl.py -j ../gypsum_dl/Test/sample_molecules.json
