Notes
=====

These scripts are for running -DL on the clusters maintained by the University
of Pittsburgh's Center for Research Computing. They will be useful mostly for
people working in the Durrant Lab, but we include them in the repository in
case they are helpful for others.
