Details for running AutoGrow4 can be found in the file TUTORIAL.md located
within the directory /autogrow4/tutorial/.
