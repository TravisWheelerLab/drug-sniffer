Details for running AutoGrow4's accessory scripts can be found in the file TUTORIAL.md located within the directory /autogrow4/tutorial/.
