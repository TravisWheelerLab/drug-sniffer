These scripts are for testing AutoGrow4 after updates, to catch any major
bugs. Used internally by Durrant-lab members.

Run tests with both Python2 and Python3.
