# Authors

Jacob O. Spiegel
Jacob D. Durrant

# Acknowledgments

Kevin C Cassidy,
Harrison Green,
Erich Helleman,
Yuri Kochnev,
Patrick J. Ropp,
Pauline E. Spiegel
